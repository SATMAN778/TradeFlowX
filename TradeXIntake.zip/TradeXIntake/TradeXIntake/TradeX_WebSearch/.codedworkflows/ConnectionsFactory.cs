namespace TradeX_WebSearch
{
}