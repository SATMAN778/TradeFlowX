namespace TradeX_GmailReader
{
}